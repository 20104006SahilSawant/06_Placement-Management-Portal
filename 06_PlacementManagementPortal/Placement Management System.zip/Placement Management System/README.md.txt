1.Placement Management Portal.
2.Sahil Sawant,Jill Shah, Swapnil Sawant, Adarsh Rai.
3.Job portal is an application which connects employer and job seekers where employers are the source
of the resources and the job seeker can find and apply for their targeted job. This document provides
details about the entire software requirement specification for the online job portal. The application is
reduced as much as possible to avoid error while entering the data. It also provides error message
while entering invalid data. No formal knowledge is needed for the user to use this system. Thus, by
this all it proves it is user-friendly. Online Job Portal, as described above, can lead to error free,
secure, reliable and fast management portal.
Placement Management Portal, as described above, can lead to error free, secure, reliable and fast management
system. It can assist the user to concentrate on their other activities rather to concentrate on the
record keeping. Thus, it will help organization in better utilization of resources. The organization
can maintain computerized records without redundant entries. That means that one need not be
distracted by information that is not relevant, while being able to reach the information.